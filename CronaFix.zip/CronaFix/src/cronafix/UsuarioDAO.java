package cronafix;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {

    /**
     * Valida si el usuario y contraseña existen en la BD.
     *
     * @param usuario Nombre de usuario
     * @param contraseña Contraseña
     * @return true si existe, false si no existe
     */
    public boolean iniciarSesion(String usuario, String contraseña) {

        String sql = """
                     SELECT *
                     FROM usuarios
                     WHERE usuario = ?
                     AND contraseña = ?
                     AND estado = true
                     """;

        try (
                Connection con = Conexion.conectar();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, usuario);
            ps.setString(2, contraseña);

            ResultSet rs = ps.executeQuery();

            return rs.next();

        } catch (SQLException e) {

            System.out.println("Error Login: " + e.getMessage());
        }

        return false;
    }

    /**
     * Obtiene el rol del usuario.
     */
    public String obtenerRol(String usuario) {

        String sql = """
                     SELECT rol
                     FROM usuarios
                     WHERE usuario = ?  
                     """;

        try (
                Connection con = Conexion.conectar();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, usuario);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                return rs.getString("rol");
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }

        return null;
    }
}